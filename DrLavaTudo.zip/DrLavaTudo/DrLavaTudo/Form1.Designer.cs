﻿namespace DrLavaTudo
{
    partial class Ordem_de_Servico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_idOs = new System.Windows.Forms.Label();
            this.lbl_datacontratacaoOs = new System.Windows.Forms.Label();
            this.lbl_dataexecucaoOs = new System.Windows.Forms.Label();
            this.txt_idOs = new System.Windows.Forms.TextBox();
            this.msk_datacontratacaoOs = new System.Windows.Forms.MaskedTextBox();
            this.msk_dataexecucaoOs = new System.Windows.Forms.MaskedTextBox();
            this.lbl_idCliente = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.col_idServico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_nomeServico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_valorfinalServico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_custoempresaServico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_rua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_numero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_complemento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_cidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_bairro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_idOs
            // 
            this.lbl_idOs.AutoSize = true;
            this.lbl_idOs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_idOs.Location = new System.Drawing.Point(12, 13);
            this.lbl_idOs.Name = "lbl_idOs";
            this.lbl_idOs.Size = new System.Drawing.Size(34, 18);
            this.lbl_idOs.TabIndex = 0;
            this.lbl_idOs.Text = "OS:";
            // 
            // lbl_datacontratacaoOs
            // 
            this.lbl_datacontratacaoOs.AutoSize = true;
            this.lbl_datacontratacaoOs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_datacontratacaoOs.Location = new System.Drawing.Point(12, 149);
            this.lbl_datacontratacaoOs.Name = "lbl_datacontratacaoOs";
            this.lbl_datacontratacaoOs.Size = new System.Drawing.Size(149, 18);
            this.lbl_datacontratacaoOs.TabIndex = 1;
            this.lbl_datacontratacaoOs.Text = "Data da Contratação:";
            // 
            // lbl_dataexecucaoOs
            // 
            this.lbl_dataexecucaoOs.AutoSize = true;
            this.lbl_dataexecucaoOs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dataexecucaoOs.Location = new System.Drawing.Point(374, 150);
            this.lbl_dataexecucaoOs.Name = "lbl_dataexecucaoOs";
            this.lbl_dataexecucaoOs.Size = new System.Drawing.Size(133, 18);
            this.lbl_dataexecucaoOs.TabIndex = 6;
            this.lbl_dataexecucaoOs.Text = "Data da Execução:";
            // 
            // txt_idOs
            // 
            this.txt_idOs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_idOs.Location = new System.Drawing.Point(52, 12);
            this.txt_idOs.Name = "txt_idOs";
            this.txt_idOs.Size = new System.Drawing.Size(186, 21);
            this.txt_idOs.TabIndex = 7;
            // 
            // msk_datacontratacaoOs
            // 
            this.msk_datacontratacaoOs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msk_datacontratacaoOs.Location = new System.Drawing.Point(167, 147);
            this.msk_datacontratacaoOs.Mask = "00/00/0000";
            this.msk_datacontratacaoOs.Name = "msk_datacontratacaoOs";
            this.msk_datacontratacaoOs.Size = new System.Drawing.Size(71, 22);
            this.msk_datacontratacaoOs.TabIndex = 8;
            this.msk_datacontratacaoOs.ValidatingType = typeof(System.DateTime);
            // 
            // msk_dataexecucaoOs
            // 
            this.msk_dataexecucaoOs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msk_dataexecucaoOs.Location = new System.Drawing.Point(529, 149);
            this.msk_dataexecucaoOs.Mask = "00/00/0000";
            this.msk_dataexecucaoOs.Name = "msk_dataexecucaoOs";
            this.msk_dataexecucaoOs.Size = new System.Drawing.Size(71, 22);
            this.msk_dataexecucaoOs.TabIndex = 9;
            this.msk_dataexecucaoOs.ValidatingType = typeof(System.DateTime);
            // 
            // lbl_idCliente
            // 
            this.lbl_idCliente.AutoSize = true;
            this.lbl_idCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_idCliente.Location = new System.Drawing.Point(10, 66);
            this.lbl_idCliente.Name = "lbl_idCliente";
            this.lbl_idCliente.Size = new System.Drawing.Size(120, 18);
            this.lbl_idCliente.TabIndex = 10;
            this.lbl_idCliente.Text = "Nome do cliente:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(136, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(464, 21);
            this.textBox1.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 18);
            this.label1.TabIndex = 12;
            this.label1.Text = "Email:";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(136, 106);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(464, 21);
            this.textBox2.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(617, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 18);
            this.label2.TabIndex = 14;
            this.label2.Text = "Data de Nascimento:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(861, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 18);
            this.label3.TabIndex = 15;
            this.label3.Text = "Celular:";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox1.Location = new System.Drawing.Point(772, 63);
            this.maskedTextBox1.Mask = "00/00/0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(71, 22);
            this.maskedTextBox1.TabIndex = 16;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox2.Location = new System.Drawing.Point(955, 63);
            this.maskedTextBox2.Mask = "(00) 00000-0000";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(103, 22);
            this.maskedTextBox2.TabIndex = 17;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox3.Location = new System.Drawing.Point(955, 107);
            this.maskedTextBox3.Mask = "(00) 00000-0000";
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(103, 22);
            this.maskedTextBox3.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(861, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 18);
            this.label4.TabIndex = 18;
            this.label4.Text = "Residencial:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_idServico,
            this.col_nomeServico,
            this.col_valorfinalServico,
            this.col_custoempresaServico,
            this.col_rua,
            this.col_numero,
            this.col_complemento,
            this.col_cidade,
            this.col_bairro,
            this.col_estado});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView1.Location = new System.Drawing.Point(13, 225);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1046, 172);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // col_idServico
            // 
            this.col_idServico.HeaderText = "ID";
            this.col_idServico.Name = "col_idServico";
            this.col_idServico.ReadOnly = true;
            // 
            // col_nomeServico
            // 
            this.col_nomeServico.HeaderText = "Descrição";
            this.col_nomeServico.Name = "col_nomeServico";
            this.col_nomeServico.ReadOnly = true;
            // 
            // col_valorfinalServico
            // 
            this.col_valorfinalServico.HeaderText = "Valor Final";
            this.col_valorfinalServico.Name = "col_valorfinalServico";
            this.col_valorfinalServico.ReadOnly = true;
            // 
            // col_custoempresaServico
            // 
            this.col_custoempresaServico.HeaderText = "Custo";
            this.col_custoempresaServico.Name = "col_custoempresaServico";
            this.col_custoempresaServico.ReadOnly = true;
            // 
            // col_rua
            // 
            this.col_rua.HeaderText = "Rua";
            this.col_rua.Name = "col_rua";
            this.col_rua.ReadOnly = true;
            // 
            // col_numero
            // 
            this.col_numero.HeaderText = "Número";
            this.col_numero.Name = "col_numero";
            this.col_numero.ReadOnly = true;
            // 
            // col_complemento
            // 
            this.col_complemento.HeaderText = "Complemento";
            this.col_complemento.Name = "col_complemento";
            this.col_complemento.ReadOnly = true;
            // 
            // col_cidade
            // 
            this.col_cidade.HeaderText = "Cidade";
            this.col_cidade.Name = "col_cidade";
            this.col_cidade.ReadOnly = true;
            // 
            // col_bairro
            // 
            this.col_bairro.HeaderText = "Bairro";
            this.col_bairro.Name = "col_bairro";
            this.col_bairro.ReadOnly = true;
            // 
            // col_estado
            // 
            this.col_estado.HeaderText = "Estado";
            this.col_estado.Name = "col_estado";
            this.col_estado.ReadOnly = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 18);
            this.label5.TabIndex = 21;
            this.label5.Text = "Serviços:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(377, 10);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 35;
            this.button2.Text = "Consultar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Ordem_de_Servico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 416);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.maskedTextBox3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.maskedTextBox2);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl_idCliente);
            this.Controls.Add(this.msk_dataexecucaoOs);
            this.Controls.Add(this.msk_datacontratacaoOs);
            this.Controls.Add(this.txt_idOs);
            this.Controls.Add(this.lbl_dataexecucaoOs);
            this.Controls.Add(this.lbl_datacontratacaoOs);
            this.Controls.Add(this.lbl_idOs);
            this.Name = "Ordem_de_Servico";
            this.Text = "Ordem de Serviço";
            this.Load += new System.EventHandler(this.Ordem_de_Servico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_idOs;
        private System.Windows.Forms.Label lbl_datacontratacaoOs;
        private System.Windows.Forms.Label lbl_dataexecucaoOs;
        private System.Windows.Forms.TextBox txt_idOs;
        private System.Windows.Forms.MaskedTextBox msk_datacontratacaoOs;
        private System.Windows.Forms.MaskedTextBox msk_dataexecucaoOs;
        private System.Windows.Forms.Label lbl_idCliente;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_idServico;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_nomeServico;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_valorfinalServico;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_custoempresaServico;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_rua;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_numero;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_complemento;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_cidade;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_bairro;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_estado;
    }
}

